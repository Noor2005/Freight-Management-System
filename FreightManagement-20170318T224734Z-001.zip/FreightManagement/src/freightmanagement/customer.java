
package freightmanagement;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class customer {
    private String customerID;
    private String customerName;
    private double load;
   
    private String FreightCharge;
    private String Source;
    private String RouteId;
    private String date;
    private String destination;
    private String ship;
    private String clientName;
   public customer(){};
    public customer(String clientName,String customerID, String customerName,String RouteId, String Source,String date,String destination,String ship,double load,String FreightCharge) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.Source = Source;
        this.RouteId = RouteId;
        this.date = date;
        this.destination = destination;
        this.ship = ship;
        this.clientName = clientName;
        this.load=load;
        this.FreightCharge=FreightCharge;
    }

    public String getSource() {
        return Source;
    }

    public void setSource(String Source) {
        this.Source = Source;
    }

    public String getRouteId() {
        return RouteId;
    }

    public void setRouteId(String RouteId) {
        this.RouteId = RouteId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getShip() {
        return ship;
    }

    public void setShip(String ship) {
        this.ship = ship;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

   
  
    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

   

    public double getLoad() {
        return load;
    }

    public void setLoad(double load) {
        this.load = load;
    }

    public String getFreightCharge() {
        return FreightCharge;
    }

    public void setFreightCharge(String FreightCharge) {
        this.FreightCharge = FreightCharge;
    }

    @Override
    public String toString() {
        return  customerID + " " + customerName + " " + load +" " + RouteId+" " + Source+" " +destination+" " +date+" " +clientName+" " + ship+" " +FreightCharge ;
    }
    
     public void WriteToFile()
    {
        try  //exception handling- if file is missing
        {
            File outFile= new File("freight.txt");
            FileWriter fWriter = new FileWriter(outFile,true);
            PrintWriter pWriter = new PrintWriter(fWriter);
            pWriter.println(this.toString());
            System.out.println("customer written to text file");
            pWriter.close();
          
        }
        catch(IOException ex)
        {
            
        }
    }
    
}
