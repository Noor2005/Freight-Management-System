
package freightmanagement;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class client extends RecursiveTreeObject<client> {
    
    private StringProperty ShippingCompanyID;
    private StringProperty ShippingCompanyName;
    private StringProperty leaseAmount;
    private StringProperty TypeOfContainer;
    private StringProperty leaseType;
    
    public client(){}
    
    public client (String ShippingCompanyID, String ShippingCompanyName, String leaseAmount, String leaseType, String TypeOfContainer)
    {
        this.ShippingCompanyID= new SimpleStringProperty(ShippingCompanyID);
        this.ShippingCompanyName= new SimpleStringProperty(ShippingCompanyName);
        this.leaseAmount= new SimpleStringProperty(leaseAmount);
        this.leaseType=new SimpleStringProperty(leaseType);
        this.TypeOfContainer=new SimpleStringProperty(TypeOfContainer);
    }

    public StringProperty getTypeOfContainer() {
        return TypeOfContainer;
    }

    public void setTypeOfContainer(String TypeOfContainer) {
        this.TypeOfContainer = new SimpleStringProperty(TypeOfContainer);
    }

    public StringProperty getLeaseType() {
        return leaseType;
    }

    public void setLeaseType(String leaseType) {
        this.leaseType =new SimpleStringProperty(leaseType);
    }
    
   
    
    public StringProperty getShippingComapnyID()
    {
        return ShippingCompanyID;
    }
    public void setShippingCompanyID(String ShippingCompanyID)
    {
        this.ShippingCompanyID=new SimpleStringProperty(ShippingCompanyID);
    }
    
     public StringProperty getShippingComapnyName()
    {
        return ShippingCompanyName;
    }
    public void setShippingCompanyName(String ShippingCompanyName)
    {
        this.ShippingCompanyName= new SimpleStringProperty(ShippingCompanyName);
    }

    public StringProperty getLeaseAmount() {
        return leaseAmount;
    }

    public void setLeaseAmount(String leaseAmount) {
        this.leaseAmount =new SimpleStringProperty( leaseAmount);
    }
    
    public String toString()
    {
        return ShippingCompanyID+""+ShippingCompanyName+""+leaseAmount+""+leaseType+""+TypeOfContainer;
    }
    
   }
    

