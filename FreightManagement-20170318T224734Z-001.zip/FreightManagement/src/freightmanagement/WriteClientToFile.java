/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package freightmanagement;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;


public class WriteClientToFile {
    
    private String ShippingCompanyID;
    private String ShippingCompanyName;
    private String TypeOfContainer;
    private String leaseAmount;
    private String leaseType;

    public WriteClientToFile(){}
     
    public WriteClientToFile(String ShippingCompanyID, String ShippingCompanyName,String leaseAmount, String TypeOfContainer,String leaseType )
    {
        this.ShippingCompanyID= ShippingCompanyID;
        this.ShippingCompanyName= ShippingCompanyName;
        this.TypeOfContainer=TypeOfContainer;
        this.leaseAmount=leaseAmount;
        this.leaseType=leaseType;
        
        
    }

    public String getLeaseType() {
        return leaseType;
    }

    public void setLeaseType(String leaseType) {
        this.leaseType = leaseType;
    }
    

    public String getTypeOfContainer() {
        return TypeOfContainer;
    }

    public void setTypeOfContainer(String TypeOfContainer) {
        this.TypeOfContainer = TypeOfContainer;
    }

   
    
  
      public String getleaseAmount() {
        return leaseAmount;
    }

    public void setleaseAmount(String leaseAmount) {
        this.leaseAmount = leaseAmount;
        
       
    }
   
    

    
    public String getShippingComapnyID()
    {
        return ShippingCompanyID;
    }
    public void setShippingCompanyID(String ShippingCompanyID)
    {
        this.ShippingCompanyID= ShippingCompanyID;
    }
    
     public String getShippingComapnyName()
    {
        return ShippingCompanyName;
    }
    public void setShippingCompanyName(String ShippingCompanyName)
    {
        this.ShippingCompanyName=ShippingCompanyName;
    }
    
    public String toString()
    {
        return ShippingCompanyID+" "+ShippingCompanyName+" "+leaseAmount+" "+TypeOfContainer+" "+leaseType;
    }
    
    
    @Override
    public boolean equals(Object obj)
    {
          return (this.ShippingCompanyID.equals(((WriteClientToFile) obj).ShippingCompanyID) && (this.ShippingCompanyName
                .equals(((WriteClientToFile) obj).ShippingCompanyName)));

    }

   
    
    public void WriteToFile()
    {
        try  //exception handling- if file is missing
        {
            File outFile= new File("Client.txt");
            FileWriter fWriter = new FileWriter(outFile,true);
            PrintWriter pWriter = new PrintWriter(fWriter);
            pWriter.println(this.toString());
            System.out.println("data written to text file");
            pWriter.close();
          
        }
        catch(IOException ex)
        {
            
        }
    }
     
   
}
