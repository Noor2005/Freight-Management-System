
package freightmanagement;


abstract class Leasing {
    protected double amountOfYears;
    
    public Leasing(){};
    public Leasing(double amountOfYears)
    {
        this.amountOfYears=amountOfYears;
    }

    public double getAmountOfYears() {
        return amountOfYears;
    }

    public void setAmountOfYears(double amountOfYears) {
        this.amountOfYears = amountOfYears;
    }
    

       public abstract double CalculateLeaseAmount(); 

    
    
    
}
