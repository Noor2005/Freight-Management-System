
package freightmanagement;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


public class Route {
    
    private String routeId;
    private String source;
    private String destination;
    private String date;
    private String NumOfPorts;
    private double distance;
    private String Ports;
    private String ClientName;
    private String Ship;
    
    Route(){}
    Route(String ClientName,String Ship,String source, String destination, String date, String NumOfPorts, double distance, String Ports, String routeId)
    {
       this.source = source;
        this.destination = destination;
        this.date = date;  
        this.ClientName=ClientName;
        this.Ship=Ship;
        this.NumOfPorts= NumOfPorts;
        this.distance= distance;
        this.Ports= Ports;
        this.routeId=routeId;
    }

    public String getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    public String getClientName() {
        return ClientName;
    }

    public void setClientName(String ClientName) {
        this.ClientName = ClientName;
    }

    public String getShip() {
        return Ship;
    }

    public void setShip(String Ship) {
        this.Ship = Ship;
    }

    public String getNumOfPorts() {
        return NumOfPorts;
    }

    public void setNumOfPorts(String NumOfPorts) {
        this.NumOfPorts = NumOfPorts;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public String getPorts() {
        return Ports;
    }

    public void setPorts(String Ports) {
        this.Ports = Ports;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    
    
   
    
   

    @Override
    public String toString() {
        
        return routeId+" "+ date+" "+source+" "+destination+" "+ClientName+" "+Ship+" "+NumOfPorts+" "+distance+" "+Ports;
    }

    public void WriteToFile()
    {
        try  //exception handling- if file is missing
        {
            File outFile= new File("Routes.txt");
            FileWriter fWriter = new FileWriter(outFile,true);
            PrintWriter pWriter = new PrintWriter(fWriter);
            pWriter.println(this.toString());
            System.out.println("routes written to routes file");
            pWriter.close();
          
        }
        catch(IOException ex)
        {
            
        }
    }
     
    
}
