/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package freightmanagement;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class RoutesFO {
   ArrayList <Route> routeList=new ArrayList <Route>();
    Scanner SC = new Scanner (System.in);
    
    
     public RoutesFO (String Fname)
    {
        File file = new File ("routes.txt");
        try {
            SC=new Scanner(file);
            
            
            while (SC.hasNextLine())
                
            {
                String Line=SC.nextLine();
               
                String[]clientArr=Line.split(" ");
                
                int i=0;
                Route clientTemp=new Route();
                for (String ss:clientArr)
                {
                    if (i==0)
                    {
                        clientTemp.setRouteId(ss);
                    }
                    if (i==1)
                    {
                        clientTemp.setDate(ss);
                    }
                    if(i==2)
                    {
                        clientTemp.setSource(ss);
                    }
                    if(i==3)
                    {
                        
                        clientTemp.setDestination(ss);
                        
                    }
                     if(i==4)
                    {
                        
                        clientTemp.setClientName(ss);
                        
                    }
                      if(i==5)
                    {
                        
                        clientTemp.setShip(ss);
                        
                    }
                     if(i==6)
                    {
                        
                        clientTemp.setNumOfPorts(ss);
                        
                    }
                      if(i==7)
                    {
                        
                        clientTemp.setDistance(Double.parseDouble(ss));
                        
                    }
                        if(i==8)
                    {
                        
                        clientTemp.setPorts(ss);
                        
                    }
                   
                    i++;
                }
                routeList.add(clientTemp);
                
                
                clientTemp=null;
            }
        } catch(IOException ex)
        {
            System.out.println("cannot");
        }
        
    }
   
     public String SearchRoute(String Ci)
    {
         for (Route clientObj:routeList)
        {
            
            Iterator<Route> it = routeList.iterator(); 
            while (it.hasNext()) { 
               Route  user = it.next(); 
                if (user.getRouteId().equals(Ci)) {
    
                return ""+user;
                
                }
            }
        }
         return "";
         
    }
    
    
     
     public boolean checkId(String Ci) throws IOException 
    {
        
         for (Route clientObj:routeList)
        {
            
            Iterator<Route> it = routeList.iterator(); 
            while (it.hasNext()) { 
               Route  user = it.next(); 
                if (user.getRouteId().equals(Ci)) {
    
                    return true;
                }
                
            }
        }
        return false;
    }
     
    
}
