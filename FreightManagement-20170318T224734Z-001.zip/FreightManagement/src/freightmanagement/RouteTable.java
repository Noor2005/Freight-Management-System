
package freightmanagement;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class RouteTable extends RecursiveTreeObject<RouteTable> {
    private StringProperty source;
    private StringProperty destination;
    private StringProperty date;
    private StringProperty NumOfPorts;
    private StringProperty distance;
    private StringProperty Ports;
    private StringProperty ClientName;
    private StringProperty Ship;
    private StringProperty routeId;
    
    
    public RouteTable(){}
       public RouteTable (String routeId,String source, String destination, String date, String NumOfPorts, String distance,String Ports,String ClientName,String Ship)
    {
        this.source= new SimpleStringProperty(source);
        this.destination= new SimpleStringProperty(destination);
        this.date= new SimpleStringProperty(date);
        this.NumOfPorts=new SimpleStringProperty(NumOfPorts);
        this.distance=new SimpleStringProperty(distance);
        this.Ports=new SimpleStringProperty(Ports);
        this.ClientName=new SimpleStringProperty(ClientName);
        this.Ship=new SimpleStringProperty(Ship);
        this.routeId=new SimpleStringProperty(routeId);
    }
      public StringProperty getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId= new SimpleStringProperty(routeId);
    }

    public StringProperty getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = new SimpleStringProperty(source);
    }

    public StringProperty getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination =new SimpleStringProperty( destination);
    }

    public StringProperty getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = new SimpleStringProperty(date);
    }

    public StringProperty getNumOfPorts() {
        return NumOfPorts;
    }

    public void setNumOfPorts(String NumOfPorts) {
        this.NumOfPorts = new SimpleStringProperty(NumOfPorts);
    }

    public StringProperty getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = new SimpleStringProperty(distance);
    }

    public StringProperty getPorts() {
        return Ports;
    }

    public void setPorts(String Ports) {
        this.Ports = new SimpleStringProperty(Ports);
    }

    public StringProperty getClientName() {
        return ClientName;
    }

    public void setClientName(String ClientName) {
        this.ClientName =new SimpleStringProperty(ClientName);
    }

    public StringProperty getShip() {
        return Ship;
    }

    public void setShip(String Ship) {
        this.Ship = new SimpleStringProperty(Ship);
    }

    @Override
    public String toString() {
        return routeId+" "+ source + " " + destination + " " + date + " " + NumOfPorts + " " + distance + " " + Ports + " " + ClientName + " " + Ship;
    }
    
}
