/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package freightmanagement;

/**
 *
 * @author user
 */
public class cruises extends ship {
    cruises()
    {
       
    }
    cruises(ContractHire ContractHire,Operating Operating, Route Route,customer customer)
    {
        super.getFreightCost();
        super.CalculateFreight();
        
    }
    
      @Override
     public double CalculateContractHireLeaseAmount()
            
    {

        return ContractHire.CalculateLeaseAmount()*3;
       
    }
    
     
    
    @Override
     public double CalculateOperatingLeaseAmount()
    {
        return Operating.CalculateLeaseAmount()*3;
    }

    
    @Override
    public double getFreightCost() {
        return FreightCost;
    }

    @Override
    public void setFreightCost(double FreightCost) {
        this.FreightCost = FreightCost;
    }

    @Override
   public double CalculateFreight()
   {
       return ((Route.getDistance())*5+ (customer.getLoad()*2));
   }
 
}
