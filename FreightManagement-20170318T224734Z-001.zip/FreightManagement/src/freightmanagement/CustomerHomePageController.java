/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package freightmanagement;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTabPane;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTreeTableColumn;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Slider;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;


/**
 * FXML Controller class
 *
 * @author user
 */
public class CustomerHomePageController implements Initializable {
    @FXML
    private MenuItem OPMenuItem;
     @FXML
    private Pane paneAddClient;

    @FXML
    private JFXButton btnAddClient;
    
    @FXML
    private JFXButton btnlogout;
    
    @FXML
    private MenuButton contractHireMenuBtn;
    
    @FXML
    private MenuItem cntractHireMenuItem;
    
     @FXML
    private MenuButton chooseMenuButton;
     
    @FXML
    private JFXTextField companyNameTextField;

    @FXML
    private JFXTextField companyIDTextFeld;
    
    @FXML
    private JFXButton btnView;
    
    @FXML
    private FlowPane paneClients;
    
    @FXML
    private JFXButton btnSave;

    @FXML
    private JFXTreeTableView<client> treeView;
    
      @FXML
    private JFXTextField input;
      
     @FXML
    private JFXButton btnDel;
     @FXML
    private JFXTextField txtLeaseYears;
   
     @FXML
    private Label lblContainer;  
    @FXML
    private JFXRadioButton radContainer;
     @FXML
    private Label lblPort;
     @FXML
    private Label leaselbl;  
  
     @FXML
    private ListView<String> listP;
    @FXML
    private JFXListView<String> listPorts;
          @FXML
    private ChoiceBox<WriteClientToFile> clientChoice;
      @FXML
    private ChoiceBox containerChoice; 
          
    @FXML
    private JFXTextField txtSource;  
     
    @FXML
    private JFXTextField txtDestination;
    
    @FXML
    private DatePicker routeDate;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        updateFreightTable();
         update();
         
         updateRouteTable();
         
//         ObservableList<String> container=FXCollections.observableArrayList("Tugboat","Cruises","Containers","Cargo","Barge","Tankers");
//          containerChoice.setItems(container);
//          containerChoice.getSelectionModel().selectFirst();
//       containerChoice.getSelectionModel().selectedItemProperty()
//            .addListener((ObservableValue observable, 
//                    Object oldValue, Object newValue) -> {
//                lblContainer.setText((String)newValue);
//                
//        });
//       
      

        routesNYCtoNYC R=new routesNYCtoNYC();
        String portsArray=R.getNYports();
        String[] allports = portsArray.split(",");
        
        ObservableList<String> prt=FXCollections.observableArrayList(allports);
        
        source.setItems(prt);
        DestinationChoice.setItems(prt);
        
        source.getSelectionModel().selectFirst();
        source.getSelectionModel().selectedItemProperty()
            .addListener((ObservableValue observable, 
                    Object oldValue, Object newValue) -> {
                
                txtSource.setText((String)newValue);
                
                
        });
        
        DestinationChoice.getSelectionModel().selectFirst();
        DestinationChoice.getSelectionModel().selectedItemProperty()
            .addListener((ObservableValue observable, 
                    Object oldValue, Object newValue) -> {
                
                 txtDestination.setText((String)newValue);
        });
       

     
        input.textProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue){
               treeView.setPredicate(new Predicate<TreeItem<client>>(){
                   
                   @Override
                   public boolean test(TreeItem<client> client){
                       Boolean flag= client.getValue().getShippingComapnyID().getValue().contains(newValue);
                       return flag;
                   }
               });
           }
       });
        
        
        
        
        txtDest.textProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue){
               tableRoutes.setPredicate(new Predicate<TreeItem<RouteTable>>(){
                   
                   @Override
                   public boolean test(TreeItem<RouteTable> RouteTable){
                       Boolean flag= RouteTable.getValue().getPorts().getValue().contains(newValue);
                       return flag;
                   }
               });
           }
       });
        
    }

  @FXML
  private JFXTextField txtDest;
  @FXML
  private JFXTextField txtSrce;
    
    @FXML
    private void AddAction (ActionEvent event) throws IOException{
        paneAddClient.setVisible(true);
      
    }
   
    
   @FXML
    private void adminLogoutAction(ActionEvent event) throws IOException{

        Parent home_page_parent=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
           Scene home_page_scene = new Scene (home_page_parent);
           Stage app_stage = (Stage)((Node)event.getSource()).getScene().getWindow();
           app_stage.setScene(home_page_scene);
    } 
       @FXML
    private ChoiceBox leaseChoice;
    
    @FXML
    private JFXButton btnCalculate;
    @FXML
    private JFXRadioButton radTugboat;
    
    @FXML
    private Label lblLeaseAmount;
        
    
    @FXML
    private Label labelLeaseType;
      @FXML
    private JFXTreeTableView<RouteTable> tableRoutes;
    public void updateRouteTable()
    {
        ArrayList <RouteTable> routeList=new ArrayList <RouteTable>();
        Scanner SC = new Scanner (System.in);
        File file = new File ("routes.txt");
        try {
            SC=new Scanner(file);
            
            
            while (SC.hasNextLine())
                
            {
                String Line=SC.nextLine();
               
                String[]clientArr=Line.split(" ");
                
                int i=0;
                RouteTable clientTemp=new RouteTable();
                for (String ss:clientArr)
                {
                    if (i==0)
                    {
                        clientTemp.setRouteId(ss);
                    }
                    if (i==1)
                    {
                        clientTemp.setDate(ss);
                    }
                    if(i==2)
                    {
                        clientTemp.setSource(ss);
                    }
                    if(i==3)
                    {
                        
                        clientTemp.setDestination(ss);
                        
                    }
                     if(i==4)
                    {
                        
                        clientTemp.setClientName(ss);
                        
                    }
                      if(i==5)
                    {
                        
                        clientTemp.setShip(ss);
                        
                    }
                     if(i==6)
                    {
                        
                        clientTemp.setNumOfPorts(ss);
                        
                    }
                      if(i==7)
                    {
                        
                        clientTemp.setDistance(ss);
                        
                    }
                        if(i==8)
                    {
                        
                        clientTemp.setPorts(ss);
                        
                    }
                   
                    i++;
                }
                routeList.add(clientTemp);
                
                
                clientTemp=null;
            }
        } catch(IOException ex)
        {
            System.out.println("cannot");
        }
         
      JFXTreeTableColumn<RouteTable,String> routeId=new JFXTreeTableColumn<>("Route ID");
       routeId.setPrefWidth(80);
        routeId.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getRouteId();
            }
        });
        JFXTreeTableColumn<RouteTable,String> date=new JFXTreeTableColumn<>("Date");
        date.setPrefWidth(80);
        date.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getDate();
            }
        });
       
         JFXTreeTableColumn<RouteTable,String> source=new JFXTreeTableColumn<>("Source");
        source.setPrefWidth(80);
        source.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getSource();
            }
        });
               
         JFXTreeTableColumn<RouteTable,String> destination=new JFXTreeTableColumn<>("Destination");
        destination.setPrefWidth(80);
        destination.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getDestination();
            }
        });
        
          JFXTreeTableColumn<RouteTable,String> clientName=new JFXTreeTableColumn<>("Client Name");
        clientName.setPrefWidth(80);
        clientName.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getClientName();
            }
        });
           JFXTreeTableColumn<RouteTable,String> ship=new JFXTreeTableColumn<>("Ship");
        ship.setPrefWidth(80);
        ship.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getShip();
            }
        });
        
       
           JFXTreeTableColumn<RouteTable,String> NumOfPorts=new JFXTreeTableColumn<>("Port No.");
        NumOfPorts.setPrefWidth(70);
        NumOfPorts.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getNumOfPorts();
            }
        });
        
             JFXTreeTableColumn<RouteTable,String> distance=new JFXTreeTableColumn<>("Distance");
        distance.setPrefWidth(80);
        distance.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getDistance();
            }
        });
        
           JFXTreeTableColumn<RouteTable,String> port=new JFXTreeTableColumn<>("Intermediate Ports");
        port.setPrefWidth(80);
        port.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<RouteTable,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<RouteTable, String> param) {
                return param.getValue().getValue().getPorts();
            }
        });
       
        ObservableList<RouteTable> clients = FXCollections.observableArrayList();
        for (RouteTable clientObj:routeList)
        {
            clients.add(clientObj);
            
        }
        final TreeItem<RouteTable>root=new RecursiveTreeItem<RouteTable>(clients,RecursiveTreeObject::getChildren);
       
        tableRoutes.getColumns().setAll(routeId,date,source,destination,clientName,ship,NumOfPorts,distance,port);
        tableRoutes.setRoot(root);
        tableRoutes.setShowRoot(false);  
        
    }
    
    public void updateFreightTable()
    {
         ArrayList <CusTble> routeList=new ArrayList <CusTble>();
        Scanner SC = new Scanner (System.in);
        File file = new File ("freight.txt");
        try {
            SC=new Scanner(file);
            
            
            while (SC.hasNextLine())
                
            {
                String Line=SC.nextLine();
               
                String[]clientArr=Line.split(" ");
                
                int i=0;
               CusTble clientTemp=new CusTble();
                for (String ss:clientArr)
                {
                    if (i==0)
                    {
                        clientTemp.setCustomerID(ss);
                    }
                    if (i==1)
                    {
                        clientTemp.setcustomerName(ss);
                    }
                    if(i==2)
                    {
                        clientTemp.setload(ss);
                    }
                     if(i==3)
                    {
                        
                        clientTemp.setRouteId(ss);
                        
                    }
                    if(i==4)
                    {
                        
                        clientTemp.setSource(ss);
                        
                    }
                     if(i==5)
                    {
                        
                        clientTemp.setDestination(ss);
                        
                    }
                      if(i==6)
                    {
                        
                        clientTemp.setDate(ss);
                        
                    }
                     if(i==7)
                    {
                        
                        clientTemp.setClientName(ss);
                        
                    }
                      if(i==8)
                    {
                        
                        clientTemp.setShip(ss);
                        
                    }
                        if(i==9)
                    {
                        
                        clientTemp.setFreightCharge(ss);
                        
                    }
                   
                    i++;
                }
                routeList.add(clientTemp);
                
                
                clientTemp=null;
            }
        } catch(IOException ex)
        {
            System.out.println("cannot");
        }
            JFXTreeTableColumn<CusTble,String> load=new JFXTreeTableColumn<>("Load");
       load.setPrefWidth(80);
        load.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getload();
            }
        });
      JFXTreeTableColumn<CusTble,String> routeId=new JFXTreeTableColumn<>("Route ID");
       routeId.setPrefWidth(80);
        routeId.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getRouteId();
            }
        });
        JFXTreeTableColumn<CusTble,String> date=new JFXTreeTableColumn<>("Date");
        date.setPrefWidth(80);
        date.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getDate();
            }
        });
       
         JFXTreeTableColumn<CusTble,String> source=new JFXTreeTableColumn<>("Source");
        source.setPrefWidth(80);
        source.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getSource();
            }
        });
               
         JFXTreeTableColumn<CusTble,String> destination=new JFXTreeTableColumn<>("Destination");
        destination.setPrefWidth(80);
        destination.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getDestination();
            }
        });
        
          JFXTreeTableColumn<CusTble,String> clientName=new JFXTreeTableColumn<>("Client Name");
        clientName.setPrefWidth(80);
        clientName.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getClientName();
            }
        });
           JFXTreeTableColumn<CusTble,String> ship=new JFXTreeTableColumn<>("Ship");
        ship.setPrefWidth(80);
        ship.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getShip();
            }
        });
        
       
           JFXTreeTableColumn<CusTble,String> cusId=new JFXTreeTableColumn<>("Customer ID");
        cusId.setPrefWidth(100);
        cusId.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getCustomerID();
            }
        });
        
               JFXTreeTableColumn<CusTble,String> CustomerName=new JFXTreeTableColumn<>("Customer Name");
       CustomerName.setPrefWidth(100);
        CustomerName.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getcustomerName();
            }
        });
        
            JFXTreeTableColumn<CusTble,String> Freight=new JFXTreeTableColumn<>("Freight Charge");
       Freight.setPrefWidth(100);
       Freight.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<CusTble,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<CusTble, String> param) {
                return param.getValue().getValue().getFreightCharge();
            }
        });
        
       
        ObservableList<CusTble> clients = FXCollections.observableArrayList();
        for (CusTble clientObj:routeList)
        {
            clients.add(clientObj);
            
        }
        final TreeItem<CusTble >root=new RecursiveTreeItem<CusTble>(clients,RecursiveTreeObject::getChildren);
       
        tableFreights.getColumns().setAll(cusId,CustomerName,load,routeId,source,destination,date,clientName,ship,Freight);
       tableFreights.setRoot(root);
        tableFreights.setShowRoot(false);  
        
    }
    
        @FXML
    private JFXTreeTableView <CusTble> tableFreights;
    
    
    
    @FXML
    private Label lblOutput;
      String output=" ";
      String tugboat="Tugboat";
      String contract="Contract";
      
    @FXML
    void calculateLease(ActionEvent event) {
   
        if( radTugboat.isSelected() && lblContainer.getText().equals(tugboat)    )
        {
         labelLeaseType.setText(contract);
             System.out.println("hi");
             
            tugboat t = new tugboat();
         t.ContractHire.setAmountOfYears(Double.parseDouble(txtLeaseYears.getText()));
           output= ""+t.CalculateContractHireLeaseAmount();
        
         System.out.println(output);
         lblLeaseAmount.setText(output);
        }
        else if (radContainer.isSelected() && lblContainer.getText().equals(tugboat) )
        {
         labelLeaseType.setText("Operating lease");  
          tugboat t = new tugboat();
          t.Operating.setAmountOfYears(Double.parseDouble(txtLeaseYears.getText()));
          output= ""+t.CalculateOperatingLeaseAmount();
        
         System.out.println(output);
         lblLeaseAmount.setText(output);
        }
        else if( radTugboat.isSelected() && lblContainer.getText().equals("Cruises")    )
        {
         labelLeaseType.setText(contract);
             System.out.println("hi");
             
            cruises t = new cruises();
         t.ContractHire.setAmountOfYears(Double.parseDouble(txtLeaseYears.getText()));
           output= ""+t.CalculateContractHireLeaseAmount();
        
         System.out.println(output);
         lblLeaseAmount.setText(output);
        }
        else if (radContainer.isSelected() && lblContainer.getText().equals("Cruises") )
        {
         labelLeaseType.setText("Operating lease");  
          cruises t = new cruises();
          t.Operating.setAmountOfYears(Double.parseDouble(txtLeaseYears.getText()));
          output= ""+t.CalculateOperatingLeaseAmount();
        
         System.out.println(output);
         lblLeaseAmount.setText(output);
        }

    }
     
    @FXML
    private Label lblMsg;
    
       @FXML
    void SaveAction(ActionEvent event) throws IOException {

        WriteClientToFile clientObj = new WriteClientToFile();
        String CompID =companyIDTextFeld.getText();
        String CompName=companyNameTextField.getText();
        
        FileOperations F=new FileOperations("Client.txt");
        
if (F.checkId(CompID))
{
    System.out.println("This ID already exists");
    lblMsg.setText("This ID already exists!");
    
}
else{
        clientObj.setShippingCompanyID(CompID);
        clientObj.setShippingCompanyName(CompName);
         
         clientObj.setTypeOfContainer(lblContainer.getText());
         clientObj.setLeaseType(labelLeaseType.getText());
         clientObj.setleaseAmount(output);

        clientObj.WriteToFile();
}
    }
     @FXML
    void ViewAction(ActionEvent event) {
        paneAddClient.setVisible(false);
        update();
       
        paneClients.setVisible(true);
    }
        @FXML
    private JFXButton btnAssign;
        @FXML
    private JFXTextField txtchooseShip;
            @FXML
    private JFXTextField txtRtId;
    @FXML
    private Label lblchoice;
    @FXML
    private Label lblName;
    @FXML
    private JFXButton btnSearch;
      @FXML
    private Label lblShip;
   
    @FXML
    private Label lblRtId;
    @FXML
    private Label lblRtId1;
     @FXML
    private Label lblRtId2;
     @FXML
    private Label lblRtId3;
     
      @FXML
    private Label lblShipType;
    @FXML
    private JFXButton btnSchRoute;
      @FXML
    void SearchRoute(ActionEvent event) {
      
        ShowNYPorts();
         RoutesFO f = new  RoutesFO("Routes.txt");
     
        String ports=""+ f.SearchRoute(txtRtId.getText());
        String[] pt = ports.split(" ");
            int i=0;
              
               for (String ss:pt)
               {
                   if (i==0)
                   {
                     
                       lblRtId.setText(ss);
                       
                   }
                   if(i==1)
                   {
                      lblRtId1.setText(ss);
                   }
                   if(i==4)
                   {
                       lblRtId2.setText(ss);
                   }
                    if(i==5)
                    {
                        
                        lblRtId3.setText(ss);
                        
                    }
//                      if(i==4)
//                    {
//                        
//                        clientTemp.setLeaseType(ss);
//                        
//                    }
                   i++;
               }

    }
    
          @FXML
    void SearchClient(ActionEvent event) {
        FileOperations f = new FileOperations("client.txt");
        
        String ports=""+ f.SearchClientsFromTextFile(txtchooseShip.getText());
        String[] pt = ports.split(" ");
            int i=0;
              
               for (String ss:pt)
               {
                   if (i==0)
                   {
                     
                       lblchoice.setText(ss);
                       
                   }
                   if(i==1)
                   {
                      lblName.setText(ss);
                   }
//                   if(i==2)
//                   {
//                       clientTemp.setleaseAmount(ss);
//                   }
                    if(i==3)
                    {
                        
                        lblShip.setText(ss);
                        
                    }
//                      if(i==4)
//                    {
//                        
//                        clientTemp.setLeaseType(ss);
//                        
//                    }
                   i++;
               }
//              clientList.add(clientTemp);

    }
      
    @FXML
    void Assign(ActionEvent event) {
        String date = routeDate.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        Route R=new Route();
        R.setDate(date);
        R.setDestination(txtDestination.getText());
        R.setDistance(Double.parseDouble(lblDistance.getText()));
        R.setNumOfPorts(lblPort.getText());
        R.setPorts(lblarrPorts.getText());
        R.setSource(txtSource.getText());
        R.setClientName(lblName.getText());
        R.setShip(lblShip.getText());
        R.setRouteId(lblchoice.getText());
        R.WriteToFile();
        updateRouteTable();

    }
    
public void update()
{
    ArrayList <client> clientList=new ArrayList <client>();
        Scanner SC = new Scanner (System.in);
        File file = new File ("client.txt");
        try {
            SC=new Scanner(file);
            
            
            while (SC.hasNextLine())
                
            {
                String Line=SC.nextLine();
               
                String[]clientArr=Line.split(" ");
                
                int i=0;
                client clientTemp=new client();
                for (String ss:clientArr)
                {
                    if (i==0)
                    {
                        clientTemp.setShippingCompanyID(ss);
                    }
                    if(i==1)
                    {
                        clientTemp.setShippingCompanyName(ss);
                    }
                    if(i==2)
                    {
                        
                        clientTemp.setLeaseAmount(ss);
                        
                    }
                     if(i==3)
                    {
                        
                        clientTemp.setTypeOfContainer(ss);
                        
                    }
                      if(i==4)
                    {
                        
                        clientTemp.setLeaseType(ss);
                        
                    }
                    
                    i++;
                }
                clientList.add(clientTemp);
                
                
                clientTemp=null;
            }
        } catch(IOException ex)
        {
            System.out.println("cannot");
        }
        JFXTreeTableColumn<client,String> shippingID=new JFXTreeTableColumn<>("Shipping ID");
        shippingID.setPrefWidth(80);
        shippingID.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<client,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<client, String> param) {
                return param.getValue().getValue().getShippingComapnyID();
            }
        });
        JFXTreeTableColumn<client,String> shippingName=new JFXTreeTableColumn<>("Shipping Name");
        shippingName.setPrefWidth(100);
        shippingName.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<client,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<client, String> param) {
                return param.getValue().getValue().getShippingComapnyName();
            }
        });
        JFXTreeTableColumn<client,String> leaseAmount=new JFXTreeTableColumn<>("Lease Amount");
        leaseAmount.setPrefWidth(100);
        leaseAmount.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<client,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<client, String> param) {
                return param.getValue().getValue().getLeaseAmount();
            }
        });
        
          JFXTreeTableColumn<client,String> shipType=new JFXTreeTableColumn<>("Type of Ship");
        shipType.setPrefWidth(80);
        shipType.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<client,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<client, String> param) {
                return param.getValue().getValue().getTypeOfContainer();
            }
        });
        
          JFXTreeTableColumn<client,String> leaseType=new JFXTreeTableColumn<>("Leasing service");
        leaseType.setPrefWidth(80);
        leaseType.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<client,String>,ObservableValue<String>>() {
            
            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<client, String> param) {
                return param.getValue().getValue().getLeaseType();
            }
        });
        
        
        ObservableList<client> clients = FXCollections.observableArrayList();
        for (client clientObj:clientList)
        {
            clients.add(clientObj);
            
        }
       
        final TreeItem<client>root=new RecursiveTreeItem<client>(clients,RecursiveTreeObject::getChildren);
        treeView.getColumns().setAll(shippingID,shippingName,leaseAmount,shipType,leaseType);
        treeView.setRoot(root);
        treeView.setShowRoot(false);   
}
    @FXML
    void delete(ActionEvent event) throws IOException {
       try{
        String client = input.getText();
        FileOperations F=new FileOperations("Client.txt");
        F.DeleteClient(client);
        System.out.println("yup");
        update();
       }
       catch (Exception ex)
       {
           update();
           System.out.println("dont");
       }
       
       
  
    }
    @FXML
    private JFXButton btnNY;

    @FXML
    private ChoiceBox source;
            
    @FXML
    private ChoiceBox DestinationChoice;
    
    @FXML
    private Label lblDistance;
    
    @FXML
    private JFXTextField lblarrPorts;
    
     @FXML
    void ShowNYPorts() {
        routesNYCtoNYC R=new routesNYCtoNYC();
//        lblPort.setText("Troylock");
        String Source= txtSource.getText();
      R.setSource(Source);
      System.out.println("text is"+R.getSource());
     
        R.setDestination(txtDestination.getText());
        R.getPorts();
        String ports=""+ R.getPorts();//intermediate ports
        System.out.println("ports are"+ports);
        lblarrPorts.setText(ports);
        String[] pt = ports.split(",");
        System.out.println("The number of ports is: " + pt.length);//no of ports
        lblPort.setText(""+pt.length);
        System.out.println(ports);
        ObservableList<String> port=FXCollections.observableArrayList(pt);
        listP.setItems(port);//listview
        listP.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        System.out.println("the distance between the ports is "+R.getDistance());
        lblDistance.setText(""+R.getDistance());
        
    }
    
    @FXML
    private JFXButton btnShowAssgn;

    @FXML
    private Pane assignShipPane;
    
    @FXML
    private Pane paneCustomer;

    @FXML
    void showAssPane(ActionEvent event) {
         assignShipPane.setVisible(true);
         paneCustomer.setVisible(false);

    }
    
    
    
    @FXML
    private JFXTextField txtCusName;
    @FXML
    private JFXTextField txtcusId;
    @FXML
    private JFXButton btnCalcFreight;
    @FXML
    private JFXTextField txtLoad;
    
    @FXML
    private Label lblFreight;
    
    @FXML
    void calculateFreight(ActionEvent event) {
        tugboat t = new tugboat();
        t.Route.setDistance(Double.parseDouble(lblDistance.getText()));
        t.customer.setLoad(Double.parseDouble(txtLoad.getText()));
        String freight=""+t.CalculateFreight();
        lblFreight.setText(freight);
    }
    
    
    @FXML
    private JFXButton btnAddFreight;
    @FXML
    void showcusPane(ActionEvent event) {
        paneCustomer.setVisible(true);
         assignShipPane.setVisible(false);
         
    }
    
    
    @FXML
    private JFXButton btnSave1;
    
    @FXML
    void SaveCust(ActionEvent event) {
        System.out.println("hi");
       customer c=new customer();
       c.setCustomerID(txtcusId.getText());
       c.setCustomerName(txtCusName.getText());
       c.setRouteId(lblRtId.getText());
       c.setDate(lblRtId1.getText());
       c.setSource(txtSource.getText());
        c.setDestination(txtDestination.getText());
       c.setShip(lblRtId3.getText());
       c.setClientName(lblRtId2.getText());
       c.setLoad(Double.parseDouble(txtLoad.getText()));
       c.setFreightCharge(lblFreight.getText());
       c.WriteToFile();
       updateFreightTable();

    }
}

   