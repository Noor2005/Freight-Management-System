
package freightmanagement;


 public class ship {
    protected ContractHire ContractHire;
    protected Operating Operating;
    protected double FreightCost;
    protected Route Route;
    protected customer customer;
    
    
    
    public ship()
    {
        
        this.ContractHire=new ContractHire();
        this.Operating=new Operating();
        this.Route=new Route();
        this.customer=new customer();
        
    }
    public double CalculateContractHireLeaseAmount()
            
    {

        return ContractHire.CalculateLeaseAmount();
       
    }
    
    public double CalculateOperatingLeaseAmount()
    {
        return Operating.CalculateLeaseAmount();
    }

    public double getFreightCost() {
        return FreightCost;
    }

    public void setFreightCost(double FreightCost) {
        this.FreightCost = FreightCost;
    }

   public double CalculateFreight()
   {
       return 0;
   }

   
    
}
