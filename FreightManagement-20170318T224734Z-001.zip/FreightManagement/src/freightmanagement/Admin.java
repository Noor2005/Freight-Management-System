
package freightmanagement;

public class Admin {
private loginCredentials adminlogin;


public Admin(){
    
    this.adminlogin=new loginCredentials();
    adminlogin.setUsername("admin");
    adminlogin.setPassword("123");
    
    
     
}

public String getUsername(){
   return adminlogin.getUsername();
           
}

public String getPassword(){
    
   return adminlogin.getPassword();
           
}





}
    

