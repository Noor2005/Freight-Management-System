
package freightmanagement;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class CusTble extends RecursiveTreeObject<CusTble> {
    private StringProperty source;
    private StringProperty destination;
    private StringProperty date;
    private StringProperty customerID;
    private StringProperty customerName;
    private StringProperty load;
    private StringProperty ClientName;
    private StringProperty Ship;
    private StringProperty routeId;
    private StringProperty FreightCharge;
    
    
     public CusTble(){}
       public CusTble (String routeId,String source, String destination, String date, String FreightCharge, String customerID,String customerName,String ClientName,String Ship,String load)
    {
        this.source= new SimpleStringProperty(source);
        this.destination= new SimpleStringProperty(destination);
        this.date= new SimpleStringProperty(date);
        this.customerID=new SimpleStringProperty(customerID);
        this.customerName=new SimpleStringProperty(customerName);
        this.load=new SimpleStringProperty(load);
        this.ClientName=new SimpleStringProperty(ClientName);
        this.Ship=new SimpleStringProperty(Ship);
        this.routeId=new SimpleStringProperty(routeId);
        this.FreightCharge=new SimpleStringProperty(FreightCharge);
    }
      public StringProperty getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId= new SimpleStringProperty(routeId);
    }

    public StringProperty getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = new SimpleStringProperty(source);
    }

    public StringProperty getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination =new SimpleStringProperty( destination);
    }

    public StringProperty getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = new SimpleStringProperty(date);
    }

    public StringProperty getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = new SimpleStringProperty(customerID);
    }

    public StringProperty getcustomerName() {
        return customerName;
    }

    public void setcustomerName(String customerName) {
        this.customerName = new SimpleStringProperty(customerName);
    }

    public StringProperty getload() {
        return load;
    }

    public void setload(String load) {
        this.load = new SimpleStringProperty(load);
    }

    public StringProperty getClientName() {
        return ClientName;
    }

    public void setClientName(String ClientName) {
        this.ClientName =new SimpleStringProperty(ClientName);
    }

    public StringProperty getShip() {
        return Ship;
    }

    public void setShip(String Ship) {
        this.Ship = new SimpleStringProperty(Ship);
    }

     public StringProperty getFreightCharge() {
        return FreightCharge;
    }

    public void setFreightCharge(String FreightCharge) {
        this.FreightCharge = new SimpleStringProperty(FreightCharge);
    }
    
    
}
