
package freightmanagement;


public class Operating extends Leasing{
    Operating(){}
    Operating(double amountOfYears)
    {
        super(amountOfYears);
    }

    @Override
     public double getAmountOfYears() {
        return amountOfYears;
    }

    @Override
    public void setAmountOfYears(double amountOfYears) {
        this.amountOfYears = amountOfYears;
    }
    @Override
   
      public  double CalculateLeaseAmount() {

        return  1000* getAmountOfYears();
    }
    
    
}
