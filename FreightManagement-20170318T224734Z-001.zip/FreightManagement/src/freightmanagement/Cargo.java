/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package freightmanagement;


public class Cargo extends ship{
    Cargo(){}
   Cargo(ContractHire ContractHire,Operating Operating, Route Route,customer customer)
    {
        super.getFreightCost();
        super.CalculateFreight();
        
    }
    
      @Override
     public double CalculateContractHireLeaseAmount()
            
    {

        return ContractHire.CalculateLeaseAmount()*6.5;
       
    }
    
     
    
    @Override
     public double CalculateOperatingLeaseAmount()
    {
        return Operating.CalculateLeaseAmount()*6.5;
    }

    
    @Override
    public double getFreightCost() {
        return FreightCost;
    }

    @Override
    public void setFreightCost(double FreightCost) {
        this.FreightCost = FreightCost;
    }

    @Override
   public double CalculateFreight()
   {
       return ((Route.getDistance())*5+ (customer.getLoad()*8));
   }
}
