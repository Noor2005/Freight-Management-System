
package freightmanagement;


public class Container extends ship{
    Container(){}
    Container(ContractHire ContractHire,Operating Operating, Route Route,customer customer)
    {
        super.getFreightCost();
        super.CalculateFreight();
        
    }
    
      @Override
     public double CalculateContractHireLeaseAmount()
            
    {

        return ContractHire.CalculateLeaseAmount()*4;
       
    }
    
     
    
    @Override
     public double CalculateOperatingLeaseAmount()
    {
        return Operating.CalculateLeaseAmount()*4;
    }

    
    @Override
    public double getFreightCost() {
        return FreightCost;
    }

    @Override
    public void setFreightCost(double FreightCost) {
        this.FreightCost = FreightCost;
    }

    @Override
   public double CalculateFreight()
   {
       return ((Route.getDistance())*5+ (customer.getLoad()*6));
   }
}
