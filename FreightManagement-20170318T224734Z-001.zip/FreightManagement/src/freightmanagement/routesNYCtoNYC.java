
package freightmanagement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class routesNYCtoNYC 
{
private String source;
private String Destination;
private List<String>  NYCtoNYC= Collections.unmodifiableList(
    Arrays.asList("New York","Troylock", "Waterville","Troy","Albany","Coeymans","Coxsackie",
            "Athens","Hudson", "Catskill","Saugerties","Kingston","Hydepark","Poughkeepside","Newburgh",
            "West point","Peekskill","Haverstraw","Ossinina","Nyak","TarryTown","Yonkers"));
private List<Integer>  distanceNYCtoNYC= Collections.unmodifiableList(
    Arrays.asList(134,132,132,126,115,108,102,102,99,89,80,71,66,53,45,38,33,29,25,24,16));

public routesNYCtoNYC(){}
    
    public routesNYCtoNYC(String source, String Destination,List NYCtoNYC, List distanceNYCtoNYC ){
        this.source=source;
        this.Destination=Destination;
       
        this.NYCtoNYC=NYCtoNYC;
        this.distanceNYCtoNYC=distanceNYCtoNYC;
       
        }
  public List<Integer> getdistanceNYCtoNYC()
  {
    return distanceNYCtoNYC;
  }
  
    public void setdistanceNYCtoNYC(int distance) {
         distanceNYCtoNYC.add(distance);
        }

    public List<String> getNYCtoNYC() {
        return NYCtoNYC;
        
    }
   public String getNYports()
   {
         List<String> sublist = getNYCtoNYC();  
        String csv = String.join(",", sublist);
//      return Arrays.toString(sublist.toArray()).replace("[", "").replace("]", "");    
        return csv;
   
   }

    public void setNYCtoNYC(String port) {
         NYCtoNYC.add(port);
        }
 
    public String getPorts(){

            
        int sourceIndex=getNYCtoNYC().indexOf(source);
        
        int destinationIndex=(getNYCtoNYC().indexOf(Destination))+1;
        System.out.println("source index is "+ sourceIndex);
        
         List<String> sublist = getNYCtoNYC().subList(sourceIndex, destinationIndex);  //iclude source but excludes destination

//      return Arrays.toString(sublist.toArray()).replace("[", "").replace("]", "");         
   String csv = String.join(",", sublist);
      return csv;
    }
    
    public int getDistance()
    {
        int sourceIndex=getNYCtoNYC().indexOf(source);
        int sourceDistance=getdistanceNYCtoNYC().get(sourceIndex);
        System.out.println("source distance is "+ sourceDistance);
        int destinationIndex=getNYCtoNYC().indexOf(Destination);
        int destinationDistance=getdistanceNYCtoNYC().get(destinationIndex);
         System.out.println("destination distance is "+ destinationDistance);
        
        return (sourceDistance-destinationDistance);
    }
    
    

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return Destination;
    }

    public void setDestination(String Destination) {
        this.Destination = Destination;
    }
   


    
    


}

