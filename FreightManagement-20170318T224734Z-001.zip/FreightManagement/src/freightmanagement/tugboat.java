
package freightmanagement;


public class tugboat extends ship {
    
    tugboat()
    {
       
    }
    tugboat(ContractHire ContractHire,Operating Operating, Route Route,customer customer)
    {
        super.getFreightCost();
        super.CalculateFreight();
        
    }

    
    
    
    
    @Override
     public double CalculateContractHireLeaseAmount()
            
    {

        return ContractHire.CalculateLeaseAmount();
       
    }
    
    
    @Override
     public double CalculateOperatingLeaseAmount()
    {
        return Operating.CalculateLeaseAmount();
    }

    
    @Override
    public double getFreightCost() {
        return FreightCost;
    }

    @Override
    public void setFreightCost(double FreightCost) {
        this.FreightCost = FreightCost;
    }

    @Override
   public double CalculateFreight()
   {
       return ((Route.getDistance())*10+ (customer.getLoad()*2));
   }
 
    
}
