
package freightmanagement;

public class Barge extends ship {
    Barge(){}
    Barge(ContractHire ContractHire,Operating Operating, Route Route,customer customer)
    {
        super.getFreightCost();
        super.CalculateFreight();
        
    }
    
      @Override
     public double CalculateContractHireLeaseAmount()
            
    {

        return ContractHire.CalculateLeaseAmount()*5;
       
    }
    
     
    
    @Override
     public double CalculateOperatingLeaseAmount()
    {
        return Operating.CalculateLeaseAmount()*5;
    }

    
    @Override
    public double getFreightCost() {
        return FreightCost;
    }

    @Override
    public void setFreightCost(double FreightCost) {
        this.FreightCost = FreightCost;
    }

    @Override
   public double CalculateFreight()
   {
       return ((Route.getDistance())*5+ (customer.getLoad()*7));
   }
}
