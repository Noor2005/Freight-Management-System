/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package freightmanagement;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.stage.Stage;


public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Button closeButton;
    @FXML
    private Button loginButton;
    @FXML
    private JFXTextField txtUsername;
    @FXML
    private JFXPasswordField txtPassword;
      @FXML
    private ProgressIndicator indi;
     @FXML
    private Label lblWrn;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }  
    @FXML
    private JFXButton btnCust;
    @FXML
    private void closeAction(ActionEvent event){
        Stage stage = (Stage)closeButton.getScene().getWindow();
        stage.close();
        
        
    }
    @FXML
    private void loginAction(ActionEvent event) throws IOException{
         
        FileOperations F= new FileOperations("client.txt");
        Admin ad= new Admin();
      
     
       String userName=txtUsername.getText();
       String passWord=txtPassword.getText();
       
       if(ad.getUsername().equals(userName) & ad.getPassword().equals(passWord) )
       {
           
           System.out.println("yes");
           if (ad.getPassword().equals(passWord)){
           Parent home_page_parent=FXMLLoader.load(getClass().getResource("HomePage.fxml"));
           Scene home_page_scene = new Scene (home_page_parent);
           Stage app_stage = (Stage)((Node)event.getSource()).getScene().getWindow();
           app_stage.setScene(home_page_scene);
            

            app_stage.show();
           }
       }    
       else if(F.checkId(userName) && passWord.equals(userName))
               {
            System.out.println("yes");
           
           Parent home_page_parent=FXMLLoader.load(getClass().getResource("clientHomePage.fxml"));
           Scene home_page_scene = new Scene (home_page_parent);
           Stage app_stage = (Stage)((Node)event.getSource()).getScene().getWindow();
           app_stage.setScene(home_page_scene);
            

            app_stage.show();
       }
           else{
                   
     lblWrn.setVisible(true);
           }
      
        
        
    }
    
 @FXML
    void showCust(ActionEvent event) throws IOException {
 System.out.println("yes");
           
           Parent home_page_parent=FXMLLoader.load(getClass().getResource("customerHomePage.fxml"));
           Scene home_page_scene = new Scene (home_page_parent);
           Stage app_stage = (Stage)((Node)event.getSource()).getScene().getWindow();
           app_stage.setScene(home_page_scene);
            

            app_stage.show();
    }
 
    }

    

