
package freightmanagement;


public class ContractHire extends Leasing {
    
    ContractHire(){}
    ContractHire(double amountOfYears)
    {
        super(amountOfYears);
    }

    @Override
     public double getAmountOfYears() {
        return amountOfYears;
    }

    @Override
    public void setAmountOfYears(double amountOfYears) {
        this.amountOfYears = amountOfYears;
    }
    @Override
    public  double CalculateLeaseAmount() {

        return  0.8*1000* getAmountOfYears();
    }
    
   
    
}
