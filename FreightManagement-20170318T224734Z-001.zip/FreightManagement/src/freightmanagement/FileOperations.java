
package freightmanagement;

import java.util.ArrayList;
import java.io.*;
import java.util.Iterator;
import java.util.Scanner;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;



 

public class FileOperations  {
    ArrayList <WriteClientToFile> clientList=new ArrayList <WriteClientToFile>();
    Scanner SC = new Scanner (System.in);
    
    
    public FileOperations(String Fname)
    {
        try
        {
            File file = new File ("Client.txt");
            SC=new Scanner(file);       
            while (SC.hasNextLine())
            {
               String Line=SC.nextLine();
               String[]clientArr=Line.split(" ");
               int i=0;
               WriteClientToFile clientTemp=new WriteClientToFile();
               for (String ss:clientArr)
               {
                   if (i==0)
                   {
                       clientTemp.setShippingCompanyID(ss);
                       
                   }
                   if(i==1)
                   {
                      clientTemp.setShippingCompanyName(ss);
                   }
                   if(i==2)
                   {
                       clientTemp.setleaseAmount(ss);
                   }
                   if(i==3)
                    {
                        
                        clientTemp.setTypeOfContainer(ss);
                        
                    }
                    if(i==4)
                    {
                        
                        clientTemp.setLeaseType(ss);
                        
                    }
                   i++;
               }
              clientList.add(clientTemp);
              
           
               clientTemp=null;
            }
            
        }
        catch(IOException ex)
        {
            System.out.println("cannot");
        }
    }
    public String SearchClientsFromTextFile(String Ci)
    {
         for (WriteClientToFile clientObj:clientList)
        {
            
            Iterator<WriteClientToFile> it = clientList.iterator(); 
            while (it.hasNext()) { 
                WriteClientToFile user = it.next(); 
                if (user.getShippingComapnyID().equals(Ci)) {
    
                return ""+user;
                
                }
            }
        }
         return "";
         
    }
    
            
                
     public boolean checkId(String Ci) throws IOException 
    {
        for (WriteClientToFile clientObj:clientList)
        {
            
            Iterator<WriteClientToFile> it = clientList.iterator(); 
            while (it.hasNext()) { 
                WriteClientToFile user = it.next(); 
                if (user.getShippingComapnyID().equals(Ci)) {
                    return true;
                }
                
            }
        }
        return false;
    }

   
       
    
    
    public void DeleteClient(String Ci) throws IOException 
    {
        for (WriteClientToFile clientObj:clientList)
        {
            
            Iterator<WriteClientToFile> it = clientList.iterator(); //need to convert the client array into iterator
            while (it.hasNext()) { //iterates through the iterator list
                WriteClientToFile user = it.next(); 
                if (user.getShippingComapnyID().equals(Ci)) {
                    
                    System.out.println("The client to delete is "+user);
                    it.remove();
                    System.out.println("deleted");
                    System.out.println(clientList);
                    
                      FileWriter fw = new FileWriter("Client.txt");
                          PrintWriter pw = new PrintWriter(fw);
                          pw.write("");
                          pw.flush(); 
                          pw.close();
          
          
                    
                    for (WriteClientToFile  client:clientList)
                    {
                        
                        client.WriteToFile();
                    }
                     
                    
                }
                
            }
            
 
            
            
        }
            
        }
        
    }
    
    
    

